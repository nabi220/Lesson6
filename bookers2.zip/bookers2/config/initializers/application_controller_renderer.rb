# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '491e3db5865906668eca54806111a2bba571671298e64dbe14e94dea4cfb52a0167992166df5ccf453afa4117d8d9f562475cc314f58a2c5240d462f76aca1eb'
